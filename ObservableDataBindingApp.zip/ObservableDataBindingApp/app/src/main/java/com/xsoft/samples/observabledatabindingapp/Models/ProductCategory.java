package com.xsoft.samples.observabledatabindingapp.Models;

import android.databinding.BaseObservable;
import android.databinding.Bindable;

import com.xsoft.samples.observabledatabindingapp.BR;

public class ProductCategory extends BaseObservable {

    private String id;
    private String name;

    @Bindable
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
        notifyPropertyChanged(BR.id);
    }

    @Bindable
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
        notifyPropertyChanged(BR.name);
    }
}

package com.xsoft.samples.observabledatabindingapp.Activities;

import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.xsoft.samples.observabledatabindingapp.Models.ProductCategory;
import com.xsoft.samples.observabledatabindingapp.R;
import com.xsoft.samples.observabledatabindingapp.databinding.ActivityMainBinding;
import com.xsoft.samples.observabledatabindingapp.databinding.ContentMainBinding;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityMainBinding binding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        ProductCategory productCategory = new ProductCategory();
        productCategory.setId("1");
        productCategory.setName("My Prod");
        binding.setCategory(productCategory);
        setSupportActionBar(binding.toolbar);
        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

}

package com.xsoft.samples.databindingbasicapp;

import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import com.xsoft.samples.databindingbasicapp.databinding.ProductListBinding;

/**
 * Created by Satiswar Dash on 11/1/2016.
 */

public class ProductActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ProductListBinding listBinding = DataBindingUtil.setContentView(this, R.layout.product_list);
        listBinding.setProduct(new Product(1001, "Product 1", 100.0d, "Sample descrption od product", null));
    }
}

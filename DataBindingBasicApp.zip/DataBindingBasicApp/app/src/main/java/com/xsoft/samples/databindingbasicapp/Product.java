package com.xsoft.samples.databindingbasicapp;

import android.graphics.drawable.Drawable;

public class Product {

    private final int id;
    private final String name;
    private final double price;
    private final String description;
    private final Drawable image;

    public Product(int id, String name, double price, String description, Drawable image) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.description = description;
        this.image = image;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public String getDescription() {
        return description;
    }

    public Drawable getImage() {
        return image;
    }


}
